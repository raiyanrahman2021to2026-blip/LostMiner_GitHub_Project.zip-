Upload to your GitHub repo: apk.part00, apk.part01, apk.part02 (from the earlier folder),
plus mod.zip and patch_apk.py from this pack. Then create .github/workflows/build.yml with the text of build.yml.
