precision mediump float;
uniform sampler2D textureUnit0;
varying vec2 texCoord;
uniform float global_alpha;
void main ()
{
  vec4 t = texture2D (textureUnit0, texCoord);
  gl_FragColor = vec4(t.xyz * vec3(1.08, 1.03, 0.92), t.w * global_alpha);
}
