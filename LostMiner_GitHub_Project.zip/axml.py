import struct
def strings(d):
    off=8; t,hs,sz,n,sn,fl,ss,sts=struct.unpack_from('<HHIIIIII',d,off)
    utf8=bool(fl&0x100); offs=struct.unpack_from('<%dI'%n,d,off+hs); out=[]
    for o in offs:
        p=off+ss+o
        if utf8:
            l=d[p]; p+=1
            if l&0x80: l=((l&0x7f)<<8)|d[p]; p+=1
            b=d[p]; p+=1
            if b&0x80: b=((b&0x7f)<<8)|d[p]; p+=1
            out.append(d[p:p+b].decode('utf8','replace'))
        else:
            l=struct.unpack_from('<H',d,p)[0]; p+=2
            if l&0x8000: l=((l&0x7fff)<<16)|struct.unpack_from('<H',d,p)[0]; p+=2
            out.append(d[p:p+l*2].decode('utf-16le','replace'))
    return out, off+sz
def strip_attrs(d, elem, names):
    st,pos=strings(d); out=bytearray(d[:pos]); removed=0
    while pos<len(d):
        t,hs,sz=struct.unpack_from('<HHI',d,pos); ch=bytearray(d[pos:pos+sz])
        if t==0x0102:
            nm=struct.unpack_from('<I',ch,20)[0]
            if st[nm]==elem:
                astart,asize,acount=struct.unpack_from('<HHH',ch,24)
                base=16+astart; keep=[]
                for i in range(acount):
                    a=ch[base+i*asize:base+(i+1)*asize]
                    n=struct.unpack_from('<I',a,4)[0]
                    if st[n] in names: removed+=1
                    else: keep.append(bytes(a))
                ch=ch[:base]+b''.join(keep)+ch[base+acount*asize:]
                struct.pack_into('<H',ch,28,len(keep)); struct.pack_into('<I',ch,4,len(ch))
        out+=ch; pos+=sz
    struct.pack_into('<I',out,4,len(out)); return bytes(out),removed
