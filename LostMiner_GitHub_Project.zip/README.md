# LostMiner HD - GitHub APK builder
All files are flat (no folders) so you can upload them from a phone.

## Steps
1. github.com -> New repository -> name it anything -> **Private** -> Create.
2. Click **Add file -> Upload files**. Select ALL the files from this unzipped folder
   (apk.part00, apk.part01, apk.part02, patch_apk.py, axml.py, every mod__* file, build.yml). Commit.
   (Each file is under GitHub's 25 MB web limit - that is why the APK is in parts.)
3. Click **Add file -> Create new file**. In the name box type exactly:  .github/workflows/build.yml
   (typing the slashes makes the folders). Open build.yml from this pack, copy everything, paste it in. Commit.
   (On a computer you can instead upload the whole .github folder.)
4. Open the **Actions** tab -> **Build LostMiner HD** -> **Run workflow**. Wait 1-2 minutes until it is green.
5. Open the finished run -> scroll to **Artifacts** -> download **LostMiner_HD** (a zip). Unzip it -> install LostMiner_HD.apk.

Uninstall the original game first (it uses a different signature).
