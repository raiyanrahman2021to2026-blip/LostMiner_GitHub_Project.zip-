precision mediump float;
uniform sampler2D textureUnit0;
varying vec2 texCoord;
uniform vec3 ambient;
uniform float myalpha;
uniform float global_alpha;
void main ()
{
  vec4 t = texture2D (textureUnit0, texCoord);
  vec3 a = vec3(0.1) + 0.9 * ambient;
  if (t.z != 0.0) {
    float l = dot(t.xyz, vec3(0.299, 0.587, 0.114));
    vec3 c = t.xyz * a * (0.92 + 0.18 * l);
    gl_FragColor = vec4(c, myalpha * global_alpha);
  } else {
    discard;
  }
}
