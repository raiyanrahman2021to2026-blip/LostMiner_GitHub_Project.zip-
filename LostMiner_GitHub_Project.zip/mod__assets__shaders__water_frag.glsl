precision mediump float;
uniform sampler2D textureUnit0;
varying vec2 texCoord;
varying float toadd;
varying float alpha1;
void main ()
{
  vec4 t = texture2D (textureUnit0, texCoord);
  vec3 c = t.xyz * toadd;
  if (alpha1 < 0.99) {
    float depth = clamp((1.0 - toadd) * 3.0, 0.0, 1.0);
    c *= mix(vec3(0.95, 1.04, 1.12), vec3(0.50, 0.78, 1.0), depth);
    float s = sin(texCoord.x * 620.0 + texCoord.y * 410.0) * sin(texCoord.x * 270.0 - texCoord.y * 530.0);
    c += vec3(0.9, 0.95, 1.0) * pow(max(s, 0.0), 8.0) * 0.28 * step(0.98, toadd);
  }
  gl_FragColor = vec4(c, t.w * alpha1);
}
