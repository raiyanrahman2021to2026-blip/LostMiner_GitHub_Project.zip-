"""Joins apk.part* into the original APK, applies mod__* files, writes unsigned.apk"""
import glob, zipfile, io, sys
import axml
parts = sorted(glob.glob('apk.part*'))
orig = b''.join(open(p, 'rb').read() for p in parts)
print('original size', len(orig), 'from', len(parts), 'parts')
zin = zipfile.ZipFile(io.BytesIO(orig))
repl = {}
for f in glob.glob('mod__*'):
    repl[f[5:].replace('__', '/')] = open(f, 'rb').read()
names = set(zin.namelist())
print('files to replace:', len(repl), 'missing in apk:', [k for k in repl if k not in names])
m, r = axml.strip_attrs(zin.read('AndroidManifest.xml'), 'manifest', {'requiredSplitTypes', 'splitTypes'})
print('removed split attrs:', r)
repl['AndroidManifest.xml'] = m
with zipfile.ZipFile('unsigned.apk', 'w') as zo:
    for zi in zin.infolist():
        n = zi.filename
        if n.startswith('META-INF/') and n.upper().endswith(('.RSA', '.SF', '.MF', '.DSA', '.EC')):
            continue
        ni = zipfile.ZipInfo(n, date_time=zi.date_time)
        ni.compress_type = zi.compress_type
        ni.external_attr = zi.external_attr
        zo.writestr(ni, repl.get(n, zin.read(n)))
print('wrote unsigned.apk')
