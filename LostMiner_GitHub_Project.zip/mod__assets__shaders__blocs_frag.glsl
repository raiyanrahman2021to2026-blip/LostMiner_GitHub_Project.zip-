precision highp float;
uniform sampler2D textureUnit0;
varying vec2 texCoord;
varying float vertexColor;
void main ()
{
  vec4 t = texture2D (textureUnit0, texCoord);
  if (vertexColor <= 1.0) {
    vec3 c = t.rgb * vertexColor * vec3(0.86, 0.94, 1.12);
    gl_FragColor = vec4(c, t.a * vertexColor);
  } else {
    float l = dot(t.rgb, vec3(0.299, 0.587, 0.114));
    vec3 c = mix(vec3(l), t.rgb, 1.10);
    c = (c - 0.5) * 1.07 + 0.5;
    c *= vec3(1.03, 1.01, 0.97);
    gl_FragColor = vec4(clamp(c, 0.0, 1.0), t.a);
  }
}
